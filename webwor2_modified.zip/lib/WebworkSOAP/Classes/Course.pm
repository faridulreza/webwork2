package WebworkSOAP::Classes::Course;

1;
