################################################################################
# WeBWorK Online Homework Delivery System
# Copyright &copy; 2000-2023 The WeBWorK Project, https://github.com/openwebwork
#
# This program is free software; you can redistribute it and/or modify it under
# the terms of either: (a) the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any later
# version, or (b) the "Artistic License" which comes with this package.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See either the GNU General Public License or the
# Artistic License for more details.
################################################################################

package WeBWorK::DB::Record::Problem;
use base WeBWorK::DB::Record;

=head1 NAME

WeBWorK::DB::Record::Problem - represent a record from the problem table.

=cut

use strict;
use warnings;

BEGIN {
	__PACKAGE__->_fields(
		set_id               => { type => "VARCHAR(100) NOT NULL", key => 1 },
		problem_id           => { type => "INT NOT NULL",          key => 1 },
		source_file          => { type => "TEXT" },
		value                => { type => "INT" },
		max_attempts         => { type => "INT" },
		att_to_open_children => { type => "INT" },
		counts_parent_grade  => { type => "INT" },
		showMeAnother        => { type => "INT" },
		showMeAnotherCount   => { type => "INT" },
		showHintsAfter       => { type => "INT NOT NULL DEFAULT -2" },
		# periodic re-randomization period
		prPeriod => { type => "INT" },
		# periodic re-randomization number of attempts for the current seed
		prCount => { type => "INT" },
		# a field for flags relating to this problem
		flags => { type => "TEXT" },
	);
}

1;
