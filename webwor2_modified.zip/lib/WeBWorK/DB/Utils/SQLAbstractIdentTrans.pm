################################################################################
# WeBWorK Online Homework Delivery System
# Copyright &copy; 2000-2023 The WeBWorK Project, https://github.com/openwebwork
#
# This program is free software; you can redistribute it and/or modify it under
# the terms of either: (a) the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any later
# version, or (b) the "Artistic License" which comes with this package.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.	 See either the GNU General Public License or the
# Artistic License for more details.
################################################################################

package WeBWorK::DB::Utils::SQLAbstractIdentTrans;
my $BASE;

BEGIN {
	my $sql_abstract = eval {
		require SQL::Abstract;
		if ($SQL::Abstract::VERSION > 1.87) {
			0;
		} else {
			1;
		}
	};
	$BASE = qw(SQL::Abstract) if $sql_abstract;
	$BASE = qw(SQL::Abstract::Classic) unless $sql_abstract;
}
use base $BASE;

=head1 NAME

WeBWorK::DB::Utils::SQLAbstractIdentTrans - subclass of SQL::Abstract::Classic that
allows custom hooks to transform identifiers.

=cut

use strict;
use warnings;

sub _table {
	my $self = shift;
	my $tab  = shift;
	if (ref $tab eq 'ARRAY') {
		return join ', ', map { $self->_quote_table($_) } @$tab;
	} else {
		return $self->_quote_table($tab);
	}
}

sub _quote {
	my $self  = shift;
	my $label = shift;

	return $label if $label eq '*';

	return $self->_quote_field($label)
		if !defined $self->{name_sep};

	if (defined $self->{transform_all}) {
		return $self->{transform_all}->($label);
	} elsif ($label =~ /(.+)\.(.+)/) {
		return $self->_quote_table($1) . $self->{name_sep} . $self->_quote_field($2);
	} else {
		return $self->_quote_field($label);
	}
}

sub _quote_table {
	my $self  = shift;
	my $label = shift;

	# if the table name is a scalar reference, leave it alone (but dereference it)
	return $$label if ref $label eq "SCALAR";

	# call custom transform function
	$label = $self->{transform_table}->($label)
		if defined $self->{transform_table};

	return $self->{quote_char} . $label . $self->{quote_char};
}

sub _quote_field {
	my $self  = shift;
	my $label = shift;

	# call custom transform function
	$label = $self->{transform_field}->($label)
		if defined $self->{transform_field};

	return $self->{quote_char} . $label . $self->{quote_char};
}

sub _order_by {
	my $self = shift;
	my $ref  = ref $_[0];

	my @vals = $ref eq 'ARRAY' ? @{ $_[0] } : $ref eq 'SCALAR' ? $_[0] :   # modification: don't dereference scalar refs
		$ref eq '' ? $_[0] : $self->SUPER::puke("Unsupported data struct $ref for ORDER BY");

	# modification: if an item is a scalar ref, don't quote it, only dereference it
	my $val = join ', ', map { ref $_ eq "SCALAR" ? $$_ : $self->_quote($_) } @vals;
	return $val ? $self->_sqlcase(' order by') . " $val" : '';
}

1;
